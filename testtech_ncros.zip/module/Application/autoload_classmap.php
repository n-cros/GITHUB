<?php
return array(
    'App\ModelAbstract' => realpath(__DIR__ . '/../../models/App/ModelAbstract.php'),
);